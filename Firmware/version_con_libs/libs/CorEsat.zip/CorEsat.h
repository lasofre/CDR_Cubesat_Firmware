#ifndef CorEsat_h
#define CorEsat_h

//Declaración de los pines de comunicaciones de los modulos
#define CE_PIN 7                                     //Definicion del pin CE para el RF24
#define CSN_PIN 8 


//~~~~~~~~~~~~~~~~~~~Inicializacion de modulos~~~~~~~~~~~~~~~~~~~~~
Adafruit_TSL2561_Unified tsl = Adafruit_TSL2561_Unified(TSL2561_ADDR_FLOAT, 12345);
MPU9250_DMP imu;                                    //SDA - Pin A4 SCL - Pin A5
RF24 radio(CE_PIN, CSN_PIN);                        // Hardware configuration: Set up nRF24L01 radio on SPI bus (pins 10, 11, 12, 13) plus pins 7 & 8
SFE_BMP180 bmp180;

//~~~~~~~~~~~~~~~~~~~Prototipado de Funciones~~~~~~~~~~~~~~~~~~~~~
void configureSensorTSL2561(void);
void AdqTSL2561();
void configBmp180();
void AdqBmp180();
void escribirVectorBpm180();
void configIMU();
void AdqImu();
void configSerie();                               //Confoguracion del puerto serie
void configRadio();
int leerDato();
void detenerEscucha();
void comenzarEscucha();
void escribirDato(int16_t dato);
void escribirVectorIMU();
void escribirTSL2561();
void LEDs();
#endif
